import React, { useState } from 'react';
import { Building2, CheckCircle, Store, MapPin, DollarSign, Users, AlertTriangle, TrendingUp, ChevronRight, Key } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

const MOCK_BRANCHES = [
  { id: '1', name: 'Taquería La Principal (Centro)', status: 'active', manager: 'Admin Local 1', location: 'Av. Siempre Viva 123', revenue: 24500, employees: 12, alerts: 0 },
  { id: '2', name: 'Taquería Norte', status: 'active', manager: 'Admin Local 2', location: 'Plaza Norte L-10', revenue: 18200, employees: 8, alerts: 1 },
  { id: '3', name: 'Taquería Sur (Nueva)', status: 'pending', manager: 'Pendiente', location: 'Blvd. Sur 445', revenue: 0, employees: 0, alerts: 0 },
  { id: '4', name: 'Taquería Express', status: 'active', manager: 'Admin Express', location: 'Terminal 2', revenue: 35000, employees: 15, alerts: 2 },
];

export default function SuperAdminDashboard() {
  const { createUser } = useAuth();
  const [branches, setBranches] = useState(MOCK_BRANCHES);
  
  // States para la creación de licencia local
  const [adminName, setAdminName] = useState('');
  const [adminPin, setAdminPin] = useState('');
  const [trialDays, setTrialDays] = useState('3');
  const [feedback, setFeedback] = useState('');

  const handleCreateLicense = (e) => {
    e.preventDefault();
    if (!adminName || !adminPin) {
      setFeedback('Error: Faltan datos.');
      return;
    }
    
    const expiration = new Date();
    expiration.setDate(expiration.getDate() + parseInt(trialDays, 10)); // Sumar N días
    
    const success = createUser(adminName, 'admin', adminPin, expiration.toISOString());
    if (success) {
      setFeedback(`¡Licencia de ${trialDays} días creada para ${adminName}! Su PIN es ${adminPin}.`);
      setAdminName(''); setAdminPin('');
    } else {
      setFeedback('Error: Ese PIN ya existe en la red global.');
    }
    setTimeout(() => setFeedback(''), 5000);
  };

  const approveBranch = (id) => {
    setBranches(branches.map(b => b.id === id ? { ...b, status: 'active', manager: 'Nuevo Gerente Asignado', employees: 5 } : b));
  };

  const pendingBranches = branches.filter(b => b.status === 'pending');
  const activeBranches = branches.filter(b => b.status === 'active');

  const totalRevenue = activeBranches.reduce((sum, b) => sum + b.revenue, 0);
  const totalEmployees = activeBranches.reduce((sum, b) => sum + b.employees, 0);
  const totalAlerts = activeBranches.reduce((sum, b) => sum + b.alerts, 0);

  const globalStats = [
    { label: 'Ingresos Totales (Cadena)', value: `$${totalRevenue.toLocaleString()}`, icon: <DollarSign size={24} />, color: 'var(--success)' },
    { label: 'Sucursales Operativas', value: activeBranches.length.toString(), icon: <Store size={24} />, color: 'var(--accent-color)' },
    { label: 'Empleados Totales', value: totalEmployees.toString(), icon: <Users size={24} />, color: '#3b82f6' },
    { label: 'Alertas Sucursales', value: totalAlerts.toString(), icon: <AlertTriangle size={24} />, color: 'var(--danger)' }
  ];

  return (
    <div className="page-container">
      <div style={{ display: 'flex', alignItems: 'center', gap: '15px', marginBottom: '30px' }}>
        <div style={{ background: 'var(--accent-color)', padding: '12px', borderRadius: '50%' }}>
          <Building2 size={32} color="white" />
        </div>
        <div>
          <h2 style={{ fontSize: '1.6rem', fontWeight: 700, margin: 0 }}>Centro de Control Maestro</h2>
          <p style={{ color: 'var(--text-secondary)', margin: 0 }}>Omni-Panel de Control - Cadena de Taquerías</p>
        </div>
      </div>

      {/* Métricas Globales de toda la Cadena */}
      <div className="grid-2" style={{ marginBottom: '40px' }}>
        {globalStats.map((stat, idx) => (
          <div key={idx} className="card" style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
            <div style={{ background: `${stat.color}20`, color: stat.color, padding: '15px', borderRadius: 'var(--radius-lg)' }}>
              {stat.icon}
            </div>
            <div>
              <p style={{ margin: 0, color: 'var(--text-secondary)', fontSize: '0.9rem' }}>{stat.label}</p>
              <h3 style={{ margin: 0, fontSize: '1.6rem', color: 'white' }}>{stat.value}</h3>
            </div>
          </div>
        ))}
      </div>

      {/* Franquicias Pendientes */}
      {pendingBranches.length > 0 && (
        <div style={{ marginBottom: '40px' }}>
          <h3 style={{ fontSize: '1.2rem', marginBottom: '15px', color: 'var(--warning)', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Store size={20} /> Solicitudes de Apertura / Nuevas Franquicias
          </h3>
          <div className="grid-2">
            {/* Lista de Pendientes (Mantenido igual) */}
            {pendingBranches.map(branch => (
              <div key={branch.id} className="card" style={{ border: '1px solid var(--warning)', background: 'rgba(234, 179, 8, 0.05)' }}>
                <h4 style={{ fontSize: '1.2rem', margin: '0 0 10px 0' }}>{branch.name}</h4>
                <p style={{ color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: '5px', margin: '0 0 15px 0' }}>
                  <MapPin size={16} /> {branch.location}
                </p>
                
                <button 
                  className="btn-primary" 
                  style={{ width: '100%', background: 'var(--warning)', color: '#000' }}
                  onClick={() => approveBranch(branch.id)}
                >
                  <CheckCircle size={18} /> Aprobar y Conceder Permisos
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Creador de Licencias Temporales Módulo 2 Grid */}
      <div className="grid-2" style={{ marginBottom: '40px' }}>
        
        {/* Generador de Administradores */}
        <div>
          <h3 style={{ fontSize: '1.2rem', marginBottom: '15px', color: 'var(--success)', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Key size={20} /> Generar Licencia Administrador (Con Expiración)
          </h3>
          <div className="card">
            <form onSubmit={handleCreateLicense}>
              <div style={{ marginBottom: '15px' }}>
                <label className="input-label">Nombre de Sucursal / Gerente</label>
                <input 
                  type="text" className="input-premium" placeholder="Ej. Franquicia Sur / Carlos"
                  value={adminName} onChange={(e) => setAdminName(e.target.value)}
                />
              </div>

              <div style={{ marginBottom: '15px' }}>
                <label className="input-label">Duración de la Licencia</label>
                <select 
                  className="input-premium" style={{ color: 'white' }}
                  value={trialDays} onChange={(e) => setTrialDays(e.target.value)}
                >
                  <option style={{color: 'black'}} value="3">3 Días (Demostración Corta)</option>
                  <option style={{color: 'black'}} value="7">7 Días (Semana de Prueba)</option>
                  <option style={{color: 'black'}} value="14">14 Días (Quincena)</option>
                  <option style={{color: 'black'}} value="30">30 Días (Mensual)</option>
                </select>
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label className="input-label">PIN de Activación Global</label>
                <input 
                  type="text" className="input-premium" placeholder="Ej. carlosSur44"
                  value={adminPin} onChange={(e) => setAdminPin(e.target.value)}
                />
              </div>

              <button className="btn-primary" type="submit" style={{ width: '100%', background: 'var(--success)' }}>
                <Key size={18} /> Crear Llave de Acceso
              </button>

              {feedback && (
                <div style={{ marginTop: '15px', padding: '10px', borderRadius: '5px', fontSize: '0.9rem', textAlign: 'center',
                  background: feedback.includes('Error') ? 'rgba(239,68,68,0.2)' : 'rgba(16,185,129,0.2)',
                  color: feedback.includes('Error') ? 'var(--danger)' : 'var(--success)'
                }}>
                  {feedback}
                </div>
              )}
            </form>
          </div>
        </div>

        {/* Info panel */}
        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <div className="glass-panel" style={{ padding: '25px', borderLeft: '4px solid var(--accent-color)' }}>
            <h4 style={{ color: 'white', marginBottom: '10px' }}>¿Qué ocurre despúes del tiempo final?</h4>
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem', lineHeight: '1.6' }}>
              El Administrador de la sucursal operará la App con normalidad y sin límites. 
              Sin embargo, inmediatamente al agotarse el periodo de duración elegido, la licencia 
              <strong> expirará automáticamente</strong>. Todos sus datos temporales, empleados registrados por él y su facturación serán borrados del bloque de memoria principal. Su acceso a la red será revocado y verá una advertencia de bloqueo hasta que le renueves una licencia permanente mediante este mismo centro de control maestro.
            </p>
          </div>
        </div>

      </div>

      {/* Estado Detallado por Sucursal */}
      <h3 style={{ fontSize: '1.2rem', marginBottom: '15px', color: 'var(--success)', display: 'flex', alignItems: 'center', gap: '8px' }}>
        <TrendingUp size={20} /> Rendimiento Financiero y Operativo por Sucursal
      </h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
        {activeBranches.map(branch => (
          <div key={branch.id} className="card" style={{ 
            borderLeft: branch.alerts > 0 ? '4px solid var(--danger)' : '4px solid var(--success)',
            display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap'
          }}>
            <div style={{ minWidth: '300px', marginBottom: '10px' }}>
              <h4 style={{ fontSize: '1.2rem', margin: '0 0 5px 0', display: 'flex', alignItems: 'center', gap: '10px' }}>
                {branch.name}
                {branch.alerts > 0 && (
                  <span style={{ fontSize: '0.8rem', background: 'var(--danger)', padding: '2px 8px', borderRadius: '12px' }}>
                    {branch.alerts} Alerta(s)
                  </span>
                )}
              </h4>
              <p style={{ color: 'var(--text-secondary)', margin: '0', fontSize: '0.9rem' }}>
                Gerente: {branch.manager} | Empleados: {branch.employees} | {branch.location}
              </p>
            </div>

            <div style={{ display: 'flex', gap: '40px', alignItems: 'center' }}>
              <div style={{ textAlign: 'right' }}>
                <p style={{ margin: 0, color: 'var(--text-secondary)', fontSize: '0.85rem' }}>Ingresos Brutos (Hoy)</p>
                <h2 style={{ margin: 0, color: 'var(--success)' }}>${branch.revenue.toLocaleString()}</h2>
              </div>
              <button className="btn-secondary" style={{ padding: '8px 12px', display: 'flex', alignItems: 'center', gap: '5px' }}>
                Inspeccionar <ChevronRight size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
}
