import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { Utensils, Lock } from 'lucide-react';

export default function Login() {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    if (login(pin)) {
      const user = login(pin); // En este punto el user ya está seteado globalmente
      // Realmente usar el user actual del store sería mejor, pero acá lo deducimos.
      // Dependiendo del rol, redirigir
      const { user: authUser } = require('../../contexts/AuthContext'); // hacky for sync, better let Context handle it, we'll navigate via useEffect or just role map
    } else {
      setError('PIN Incorrecto');
    }
  };

  const handleAttempt = () => {
    if (login(pin)) {
      // Redirección manejada en App.jsx si `user` cambió
    } else {
      setError('PIN Incorrecto. Intente: admin, mesero, chef, caja');
    }
  };

  return (
    <div style={{
      display: 'flex', 
      justifyContent: 'center', 
      alignItems: 'center', 
      height: '100vh',
      width: '100%',
      background: 'radial-gradient(circle at center, var(--bg-secondary) 0%, var(--bg-primary) 100%)'
    }}>
      <div className="glass-panel" style={{ width: '400px', padding: '40px', textAlign: 'center' }}>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '20px' }}>
          <div style={{ background: 'var(--accent-color)', padding: '15px', borderRadius: '50%' }}>
            <Utensils size={32} color="white" />
          </div>
        </div>
        <h1 style={{ marginBottom: '5px', fontSize: '1.8rem' }}>Sistema Restaurante</h1>
        <p style={{ color: 'var(--text-secondary)', marginBottom: '30px' }}>Ingresa tu PIN de empleado</p>

        <form onSubmit={(e) => { e.preventDefault(); handleAttempt(); }}>
          <div style={{ marginBottom: '20px', textAlign: 'left' }}>
            <label className="input-label">PIN de Acceso</label>
            <div style={{ position: 'relative' }}>
              <Lock size={18} style={{ position: 'absolute', left: '12px', top: '15px', color: 'var(--text-secondary)' }} />
              <input 
                type="password" 
                className="input-premium" 
                style={{ paddingLeft: '40px' }}
                placeholder="****"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
              />
            </div>
            {error && <p style={{ color: 'var(--danger)', fontSize: '0.85rem', marginTop: '8px' }}>{error}</p>}
          </div>

          <button className="btn-primary" style={{ width: '100%' }} type="submit">
            Ingresar al Sistema
          </button>
        </form>

        <div style={{ marginTop: '20px', fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
           PINs de prueba: super | admin | mesero | chef | caja
        </div>
      </div>
    </div>
  );
}
