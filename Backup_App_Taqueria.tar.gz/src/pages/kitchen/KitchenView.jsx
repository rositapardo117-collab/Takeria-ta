import React, { useState } from 'react';
import { ChefHat, Clock, CheckCircle } from 'lucide-react';

const MOCK_ORDERS = [
  { id: '101', table: 'Mesa 4', items: [{ name: '3x Tacos al Pastor', status: 'pending' }, { name: '2x Tacos de Asada', status: 'pending' }], time: '12 min', priority: 'high' },
  { id: '102', table: 'Mesa 2', items: [{ name: '1x Quesadilla Sencilla', status: 'pending' }], time: '5 min', priority: 'normal' },
  { id: '103', table: 'Mesa Centro', items: [{ name: '5x Tacos Suadero', status: 'pending' }, { name: '1x Volcán Pastor', status: 'pending' }], time: '2 min', priority: 'normal' }
];

export default function KitchenView() {
  const [orders, setOrders] = useState(MOCK_ORDERS);

  const getPriorityColor = (priority, timeStr) => {
    const min = parseInt(timeStr);
    if (min >= 10 || priority === 'high') return 'var(--danger)';
    if (min >= 5) return 'var(--warning)';
    return 'var(--success)';
  };

  const markOrderDone = (orderId) => {
    setOrders(orders.filter(o => o.id !== orderId));
  };

  return (
    <div className="page-container">
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '30px' }}>
        <ChefHat size={28} color="var(--accent-color)" />
        <h2 style={{ fontSize: '1.5rem', fontWeight: 600, margin: 0 }}>Monitor de Cocina (KDS)</h2>
      </div>

      <div style={{ 
        display: 'flex', 
        gap: '20px', 
        overflowX: 'auto', 
        paddingBottom: '20px',
        alignItems: 'flex-start'
      }}>
        {orders.map(order => (
          <div key={order.id} className="card" style={{ 
            minWidth: '320px', 
            borderTop: `4px solid ${getPriorityColor(order.priority, order.time)}` 
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid var(--glass-border)', paddingBottom: '15px', marginBottom: '15px' }}>
              <div style={{ fontSize: '1.2rem', fontWeight: 'bold' }}>{order.table} <span style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>#{order.id}</span></div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '5px', color: getPriorityColor(order.priority, order.time), fontWeight: 'bold' }}>
                <Clock size={16} /> {order.time}
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', minHeight: '120px' }}>
              {order.items.map((item, index) => (
                <div key={index} style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '1.1rem' }}>
                  <input type="checkbox" style={{ transform: 'scale(1.5)', accentColor: 'var(--accent-color)' }} />
                  {item.name}
                </div>
              ))}
            </div>

            <div style={{ marginTop: '20px' }}>
              <button 
                className="btn-primary" 
                style={{ width: '100%', background: 'var(--success)' }}
                onClick={() => markOrderDone(order.id)}
              >
                <CheckCircle size={18} />
                Comanda Lista
              </button>
            </div>
          </div>
        ))}

        {orders.length === 0 && (
          <div style={{ padding: '40px', color: 'var(--text-secondary)', textAlign: 'center', width: '100%' }}>
            No hay órdenes pendientes en cocina.
          </div>
        )}
      </div>
    </div>
  );
}
