import React, { useState } from 'react';
import { TrendingUp, Users, Utensils, DollarSign, UserPlus } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

export default function AdminDashboard() {
  const { usersList, createUser } = useAuth();
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState('waiter');
  const [newPin, setNewPin] = useState('');
  const [feedback, setFeedback] = useState('');

  const handleCreateUser = (e) => {
    e.preventDefault();
    if (!newName || !newPin) {
      setFeedback('Error: Completa nombre y PIN para el usuario.');
      return;
    }
    const success = createUser(newName, newRole, newPin);
    if (success) {
      setFeedback(`Usuario ${newName} creado exitosamente.`);
      setNewName('');
      setNewPin('');
    } else {
      setFeedback('Error: Ese PIN ya está en uso por otra persona.');
    }
    setTimeout(() => setFeedback(''), 3000);
  };

  const stats = [
    { label: 'Ventas Totales', value: '$8,450', icon: <DollarSign size={24} />, color: 'var(--success)' },
    { label: 'Órdenes Atendidas', value: '34', icon: <Utensils size={24} />, color: 'var(--accent-color)' },
    { label: 'Empleados Sistema', value: usersList.length.toString(), icon: <Users size={24} />, color: '#3b82f6' }
  ];

  const getRoleName = (role) => {
    switch(role) {
      case 'admin': return 'Administrador';
      case 'waiter': return 'Mesero';
      case 'kitchen': return 'Chef/Taquero';
      case 'cashier': return 'Cajero';
      default: return role;
    }
  };

  return (
    <div className="page-container">
      <h2 style={{ fontSize: '1.5rem', fontWeight: 600, marginBottom: '20px' }}>Resumen Gerencial</h2>
      
      <div className="grid-2" style={{ marginBottom: '40px' }}>
        {stats.map((stat, idx) => (
          <div key={idx} className="card" style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
            <div style={{ background: `${stat.color}20`, color: stat.color, padding: '15px', borderRadius: 'var(--radius-lg)' }}>
              {stat.icon}
            </div>
            <div>
              <p style={{ margin: 0, color: 'var(--text-secondary)', fontSize: '0.9rem' }}>{stat.label}</p>
              <h3 style={{ margin: 0, fontSize: '1.6rem', color: 'white' }}>{stat.value}</h3>
            </div>
          </div>
        ))}
      </div>

      <div className="grid-2">
        {/* Lista de Empleados */}
        <div>
          <h3 style={{ fontSize: '1.2rem', marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Users size={20} color="var(--accent-color)" /> Empleados Activos
          </h3>
          <div className="card" style={{ padding: '0', overflow: 'hidden' }}>
            {usersList.map((emp, index) => (
              <div key={index} style={{ 
                padding: '15px 20px', 
                borderBottom: index < usersList.length - 1 ? '1px solid var(--glass-border)' : 'none',
                display: 'flex', justifyContent: 'space-between'
              }}>
                <div>
                  <div style={{ fontWeight: 600 }}>{emp.name}</div>
                  <div style={{ fontSize: '0.9rem', color: 'var(--text-secondary)' }}>{getRoleName(emp.role)}</div>
                </div>
                <div style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', display: 'flex', alignItems: 'center' }}>
                  Pin: {emp.pin}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Formulario Crear Usuario */}
        <div>
          <h3 style={{ fontSize: '1.2rem', marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <UserPlus size={20} color="var(--success)" /> Nuevo Empleado
          </h3>
          <div className="card">
            <form onSubmit={handleCreateUser}>
              <div style={{ marginBottom: '15px' }}>
                <label className="input-label">Nombre del Empleado</label>
                <input 
                  type="text" className="input-premium" placeholder="Ej: Ana Rivera"
                  value={newName} onChange={(e) => setNewName(e.target.value)}
                />
              </div>

              <div style={{ marginBottom: '15px' }}>
                <label className="input-label">Rol en el Restaurante</label>
                <select 
                  className="input-premium" 
                  style={{ color: 'white' }}
                  value={newRole} onChange={(e) => setNewRole(e.target.value)}
                >
                  <option style={{color: 'black'}} value="waiter">Mesero</option>
                  <option style={{color: 'black'}} value="cashier">Cajero</option>
                  <option style={{color: 'black'}} value="kitchen">Chef/Taquero</option>
                  <option style={{color: 'black'}} value="admin">Administrador</option>
                </select>
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label className="input-label">PIN de Ingreso (Contraseña)</label>
                <input 
                  type="text" className="input-premium" placeholder="Ej: ana123"
                  value={newPin} onChange={(e) => setNewPin(e.target.value)}
                />
              </div>

              <button className="btn-primary" type="submit" style={{ width: '100%' }}>
                <UserPlus size={18} /> Asignar Empleado
              </button>

              {feedback && (
                <div style={{ marginTop: '15px', padding: '10px', borderRadius: '5px', fontSize: '0.9rem', textAlign: 'center',
                  background: feedback.includes('Error') ? 'rgba(239,68,68,0.2)' : 'rgba(16,185,129,0.2)',
                  color: feedback.includes('Error') ? 'var(--danger)' : 'var(--success)'
                }}>
                  {feedback}
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
