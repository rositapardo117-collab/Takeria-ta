import React, { useState } from 'react';
import { CreditCard, Banknote, Receipt } from 'lucide-react';

const MOCK_TICKETS = [
  { id: 'T-1004', table: 'Mesa 4', amount: 850, status: 'unpaid' },
  { id: 'T-1002', table: 'Mesa 2', amount: 450, status: 'unpaid' },
  { id: 'T-1005', table: 'Mesa Centro', amount: 1200, status: 'unpaid' },
];

export default function CashierView() {
  const [tickets, setTickets] = useState(MOCK_TICKETS);
  const [totalSales, setTotalSales] = useState(3450);

  const processPayment = (id, amount) => {
    setTickets(tickets.filter(t => t.id !== id));
    setTotalSales(prev => prev + amount);
  };

  return (
    <div className="page-container">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 600 }}>Caja y Pagos</h2>
        <div style={{ background: 'var(--bg-secondary)', padding: '10px 20px', borderRadius: 'var(--radius-md)', border: '1px solid var(--glass-border)' }}>
          <span style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginRight: '10px' }}>Corte de Caja Actual:</span>
          <span style={{ fontSize: '1.3rem', fontWeight: 700, color: 'var(--success)' }}>${totalSales}</span>
        </div>
      </div>

      <div className="grid-2">
        {tickets.map(ticket => (
          <div key={ticket.id} className="card" style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <Receipt color="var(--accent-color)" />
                <h3 style={{ margin: 0, fontSize: '1.2rem' }}>{ticket.table}</h3>
              </div>
              <span style={{ color: 'var(--text-secondary)' }}>{ticket.id}</span>
            </div>

            <div style={{ textAlign: 'center', padding: '15px 0' }}>
              <p style={{ margin: 0, color: 'var(--text-secondary)' }}>Total a Pagar</p>
              <h1 style={{ margin: 0, fontSize: '2.5rem', color: 'white' }}>${ticket.amount}</h1>
            </div>

            <div style={{ display: 'flex', gap: '10px' }}>
              <button 
                className="btn-primary" 
                style={{ flex: 1, background: 'var(--bg-primary)', border: '1px solid var(--success)', color: 'var(--success)' }}
                onClick={() => processPayment(ticket.id, ticket.amount)}
              >
                <Banknote size={18} /> Efectivo
              </button>
              <button 
                className="btn-primary" 
                style={{ flex: 1, background: 'var(--accent-color)' }}
                onClick={() => processPayment(ticket.id, ticket.amount)}
              >
                <CreditCard size={18} /> Tarjeta
              </button>
            </div>
          </div>
        ))}

        {tickets.length === 0 && (
          <div style={{ gridColumn: '1 / -1', padding: '50px', textAlign: 'center', color: 'var(--text-secondary)' }}>
            No hay tickets pendientes de cobro.
          </div>
        )}
      </div>
    </div>
  );
}
