import React, { useState } from 'react';
import { Plus, Coffee, CheckCircle } from 'lucide-react';

const MOCK_TABLES = [
  { id: 1, number: 'Mesa 1', status: 'available' },
  { id: 2, number: 'Mesa 2', status: 'occupied', bill: 450 },
  { id: 3, number: 'Mesa 3', status: 'available' },
  { id: 4, number: 'Mesa 4', status: 'waiting_food' },
  { id: 5, number: 'Mesa Centro', status: 'occupied', bill: 1200 },
];

export default function WaiterView() {
  const [tables, setTables] = useState(MOCK_TABLES);

  const getStatusColor = (status) => {
    switch(status) {
      case 'available': return 'var(--success)';
      case 'occupied': return 'var(--danger)';
      case 'waiting_food': return 'var(--warning)';
      default: return 'var(--text-secondary)';
    }
  };

  const getStatusText = (status) => {
    switch(status) {
      case 'available': return 'Disponible';
      case 'occupied': return 'Ocupada';
      case 'waiting_food': return 'Esperando Comida';
      default: return 'Desconocido';
    }
  };

  return (
    <div className="page-container">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 600 }}>Vista de Mesas</h2>
        <button className="btn-primary">
          <Plus size={20} />
          Nuevo Pedido Rápido
        </button>
      </div>

      <div className="grid-2">
        {tables.map(table => (
          <div key={table.id} className="card" style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h3 style={{ fontSize: '1.2rem', margin: 0 }}>{table.number}</h3>
              <div style={{ 
                background: `${getStatusColor(table.status)}20`, /* transparency */
                color: getStatusColor(table.status),
                padding: '4px 10px',
                borderRadius: '20px',
                fontSize: '0.8rem',
                fontWeight: 600,
                display: 'flex',
                alignItems: 'center',
                gap: '5px'
              }}>
                <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: getStatusColor(table.status) }}></div>
                {getStatusText(table.status)}
              </div>
            </div>

            <div style={{ flex: 1 }}>
              {table.status !== 'available' ? (
                <div>
                  <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>Consumo actual:</p>
                  <p style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--text-primary)' }}>${table.bill}</p>
                </div>
              ) : (
                <div style={{ height: '50px', display: 'flex', alignItems: 'center', color: 'var(--text-secondary)', fontStyle: 'italic' }}>
                  Lista para nuevos clientes
                </div>
              )}
            </div>

            <div style={{ display: 'flex', gap: '10px' }}>
              {table.status === 'available' ? (
                <button className="btn-primary" style={{ flex: 1, padding: '8px' }}>
                  <Coffee size={16} /> Abrir Mesa
                </button>
              ) : (
                <>
                  <button className="btn-secondary" style={{ flex: 1, padding: '8px' }}>Ver Orden</button>
                  <button className="btn-primary" style={{ flex: 1, padding: '8px', background: 'var(--success)' }}>
                    <Plus size={16} /> Agregar
                  </button>
                </>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
