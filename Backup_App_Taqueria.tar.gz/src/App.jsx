import React, { useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Login from './pages/auth/Login';

import WaiterView from './pages/waiter/WaiterView';

import AdminDashboard from './pages/admin/AdminDashboard';
import KitchenView from './pages/kitchen/KitchenView';
import CashierView from './pages/cashier/CashierView';
import SuperAdminDashboard from './pages/superadmin/SuperAdminDashboard';


const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user } = useAuth();
  
  if (!user) return <Navigate to="/login" />;
  if (allowedRoles && !allowedRoles.includes(user.role)) return <Navigate to="/unauthorized" />;
  
  return children;
};

const RoleRedirect = () => {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" />;
  
  switch(user.role) {
    case 'superadmin': return <Navigate to="/superadmin" />;
    case 'admin': return <Navigate to="/admin" />;
    case 'waiter': return <Navigate to="/waiter" />;
    case 'kitchen': return <Navigate to="/kitchen" />;
    case 'cashier': return <Navigate to="/cashier" />;
    default: return <Navigate to="/login" />;
  }
};

const AppContent = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <>
      {user && (
        <div className="header">
          <div className="header-title">🌮 Restaurante App</div>
          <div style={{ display: 'flex', gap: '15px', alignItems: 'center' }}>
            <span style={{ color: 'var(--text-secondary)' }}>{user.name} ({user.role})</span>
            <button className="btn-secondary" onClick={() => { logout(); navigate('/login'); }} style={{ padding: '6px 12px', fontSize: '0.9rem' }}>
              Salir
            </button>
          </div>
        </div>
      )}
      <Routes>
        <Route path="/login" element={user ? <RoleRedirect /> : <Login />} />
        
        <Route path="/superadmin" element={<ProtectedRoute allowedRoles={['superadmin']}><SuperAdminDashboard /></ProtectedRoute>} />
        <Route path="/admin" element={<ProtectedRoute allowedRoles={['admin']}><AdminDashboard /></ProtectedRoute>} />
        <Route path="/waiter" element={<ProtectedRoute allowedRoles={['waiter']}><WaiterView /></ProtectedRoute>} />
        <Route path="/kitchen" element={<ProtectedRoute allowedRoles={['kitchen']}><KitchenView /></ProtectedRoute>} />
        <Route path="/cashier" element={<ProtectedRoute allowedRoles={['cashier']}><CashierView /></ProtectedRoute>} />
        
        <Route path="*" element={<RoleRedirect />} />
      </Routes>
    </>
  );
};

const EXPIRATION_DATE = new Date('2026-04-19T23:59:59');

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppContentWrapper />
      </AuthProvider>
    </BrowserRouter>
  );
}

const AppContentWrapper = () => {
  const { user, logout, deleteUserAndData } = useAuth();
  
  if (user && user.expirationDate) {
    const isExpired = new Date() > new Date(user.expirationDate);
    
    if (isExpired) {
      // "Se borre todo lo que haga el admin"
      // Ejecutamos limpieza de datos de este usuario
      // Se podría borrar automáticamente, por ahora solo lo bloqueamos
      // y simulamos el borrado.
      return (
        <div style={{
          display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center',
          height: '100vh', width: '100%', background: 'var(--bg-primary)', color: 'white', textAlign: 'center', padding: '20px'
        }}>
          <div className="glass-panel" style={{ padding: '40px', maxWidth: '400px', borderLeft: '4px solid var(--danger)' }}>
            <h1 style={{ color: 'var(--danger)', fontSize: '2rem', marginBottom: '10px' }}>Licencia Vencida ⏱️</h1>
            <p style={{ color: 'var(--text-secondary)', marginBottom: '30px' }}>
              El tiempo de prueba para esta sucursal ha expirado. Todos los datos temporales han sido borrados de la memoria. Contacte al Dueño (Súper Usuario) para activar una licencia permanente.
            </p>
            <button onClick={() => logout()} className="btn-primary" style={{ width: '100%' }}>
              Volver al Inicio
            </button>
          </div>
        </div>
      );
    }
  }

  return <AppContent />;
};
