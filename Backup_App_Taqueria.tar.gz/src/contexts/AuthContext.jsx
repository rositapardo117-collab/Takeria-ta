import React, { createContext, useContext, useState } from 'react';

const AuthContext = createContext(undefined);

const INITIAL_USERS = [
  { id: '0', name: 'Super Usuario Global', role: 'superadmin', pin: 'super' },
  { id: '1', name: 'Administrador Local', role: 'admin', pin: 'admin' },
  { id: '2', name: 'Juan Mesero', role: 'waiter', pin: 'mesero' },
  { id: '3', name: 'Cocina Principal', role: 'kitchen', pin: 'chef' },
  { id: '4', name: 'Caja 1', role: 'cashier', pin: 'caja' },
];

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [usersList, setUsersList] = useState(INITIAL_USERS);

  const login = (pin) => {
    const foundUser = usersList.find(u => u.pin === pin);
    if (foundUser) {
      setUser(foundUser);
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
  };

  const createUser = (name, role, pin, expirationDate = null) => {
    if (usersList.some(u => u.pin === pin)) {
      return false; // El PIN ya existe
    }
    const newUser = { id: Date.now().toString(), name, role, pin, expirationDate };
    setUsersList([...usersList, newUser]);
    return true;
  };

  const deleteUserAndData = (pinOfUserToDelete) => {
    // "Borra todo lo que haga el admin": Borramos el admin y simulamos limpieza
    setUsersList(usersList.filter(u => u.pin !== pinOfUserToDelete));
  };

  return (
    <AuthContext.Provider value={{ user, usersList, login, logout, createUser, deleteUserAndData }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
